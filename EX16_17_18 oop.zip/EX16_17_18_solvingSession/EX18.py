from abc import ABC, abstractmethod

class Person(ABC):
    def __init__(self, name, age):
        self.name = name
        self.age = age

    @abstractmethod
    def display_info(self):
        pass


class Student(Person):
    def __init__(self, name, age, student_id):
        super().__init__(name, age)
        self.student_id = student_id

    def display_info(self):
        print(f'student: {self.name}, age: {self.age}, student id: {self.student_id}')

    def show_role(self):
        print(f'{self.name} is a student')


class Teacher(Person):
    def __init__(self, name, age, employee_id):
        super().__init__(name, age)
        self.employee_id = employee_id

    def display_info(self):
        print(f'student: {self.name}, age: {self.age}, student id: {self.employee_id}')

    def show_role(self):
        print(f'{self.name} is a Teacher')


class University:
    def __init__(self):
        self.people = []

    def add_person(self, person):
        self.people.append(person)

    def display_all_info(self):
        for person in self.people:
            person.display_info()


student1 = Student('meisam', 25, "s1200")
teacher1 = Teacher('mr.Alavi', 40, "t4000")

university = University()
university.add_person(student1)
university.add_person(teacher1)

university.display_all_info()

student1.show_role()
teacher1.show_role()



