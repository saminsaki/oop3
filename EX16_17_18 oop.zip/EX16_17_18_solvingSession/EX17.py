class MyString(str):
    def find_all(self, substring):
        self = self.lower()
        indices = []
        for i in range(len(self)):
            if self.startswith(substring, i):
                indices.append(i)
        return indices

    def count_vowels(self):
        vowels = 'aeiouAEIOU'
        vowels_count = []
        for char in vowels:
            l = self.count(char)
            vowels_count.append(l)
        return sum(vowels_count)

    def is_palindrome(self):
        return self == self[::-1]

    def upper(self):
        result = []
        for char in self:
            if char.isalpha() and char not in "aeiouAEIOU":
                char = char.upper() # R
                result.append(char)
            else:
                result.append(char)

        result = ''.join(result)
        return result


my_str = MyString('radar')
print("find all Occurrences of 'o': ", my_str.find_all('o'))
print("count vowels:", my_str.count_vowels())
print("is palindrome:", my_str.is_palindrome())

modified_str = my_str.upper()
print("modified uppercase: ", modified_str)
