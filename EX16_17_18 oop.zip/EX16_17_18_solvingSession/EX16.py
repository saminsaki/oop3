class Vehicle:
    total_vehicle = 0

    def __init__(self, make, year, model):
        self.make = make
        self.year = self.valid_year(year)
        self.model = model
        self.update_total_vehicle()

    @staticmethod
    def valid_year(year):
        if isinstance(year, int) and 1000 <= year <= 9999:
            return year
        else:
            raise ValueError('Invalid year format')

    @classmethod
    def update_total_vehicle(cls):
        cls.total_vehicle += 1

    def display_vehicle(self):
        print(f'Make: {self.make}, Model: {self.model}, year: {self.year}')


c1 = Vehicle('Toyota', 2022, 'camry')
c2 = Vehicle('Saipa', 2023, 'pride')
print(c1.update_total_vehicle())

